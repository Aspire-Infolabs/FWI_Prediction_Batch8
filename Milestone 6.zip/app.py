
from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open('ridge.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    values = [
        float(request.form['Temperature']),
        float(request.form['RH']),
        float(request.form['Wind']),
        float(request.form['Rain']),
        float(request.form['FFMC']),
        float(request.form['DMC']),
        float(request.form['ISI'])
    ]
    scaled = scaler.transform([values])
    prediction = model.predict(scaled)[0]
    return render_template('home.html', prediction=round(prediction, 2))

if __name__ == "__main__":
    app.run(debug=True)
